<script> 
	function ValidaSemPreenchimento(form){
		for (i=0;i<form.length;i++){
			var obg = form[i].obrigatorio;
		if (obg==1){
		if (form[i].value == ""){
			var nome = form[i].descricao
				alert("O campo " + nome + " é obrigatório.")
			form[i].focus();
		return false;

	function enviarDados()	{
		var nome = document.getElementById("name").value;
		var email = document.getElementById("email").value;
		var text = document.getElementById("comment").value;
		d = document.getElementById("form1");
		if(d.nome.value=="" || d.nome.value.length < 50){ 
	alert( "Preencha campo NOME corretamente!" );
	d.nome.style.backgroundColor="red";
    d.nome.style.color="#ffffff";
	d.nome.focus();
	return false; 
	} 
	if( d.email.value=="" || d.email.value.indexOf('@')==-1 || d.email.value.indexOf('.')==-1 ){
	alert( "Preencha campo E-MAIL corretamente!" );
	d.email.style.backgroundColor="red";
    d.email.style.color="#ffffff";
	d.email.focus(); 
	return false;
	} 
	if (d.text.value=="") {
	alert( "Preencha o campo MENSAGEM!" );
	d.text.focus();
	return false; 
	}
	if (d.text.value.length < 300 ) {
	alert( "É necessario preencher o campo MENSAGEM com menos de 300 caracteres!" );
	d.text.style.backgroundColor="red";
    d.text.style.color="#ffffff";
	d.text.focus();
	return false; 
	}
	return true;
	
	}
	}
	}
	}
	return true
	}
</script>

